﻿using ServiceLayer.ModelDto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Interfaces
{
    public interface IBirhtInfoService
    {
        Task<BirthDto> GetById(int id);
        Task<bool> CreateNewBirth(BirthDto entity);
        IEnumerable<BirthDto> GetAllBirth();
        Task<bool> UpdateBirth(BirthDto entity);
        Task<bool> DeleteNote(int id);

        IEnumerable<BirthDto> AlreadyPass();
        IEnumerable<BirthDto> BirthSoon();
        IEnumerable<BirthDto> TodayBirth();
        IEnumerable<BirthDto> GetAllPicture();
    }
}
