﻿using AutoMapper;
using DataLayer.IRepository;
using DataLayer.Model;
using ServiceLayer.Interfaces;
using ServiceLayer.ModelDto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.ServiceLayer
{
    public class BirthService : IBirhtInfoService
    {
        private readonly IBirthRepository _birthRepository;
        private readonly IMapper _mapper;

        public BirthService(IBirthRepository birthRepository, IMapper mapper)
        { 
         _birthRepository = birthRepository;
         _mapper = mapper;
        
        }
        public IEnumerable<BirthDto> AlreadyPass()
        {
            DateOnly today = DateOnly.FromDateTime(DateTime.Today);
            DateOnly previous = today.AddDays(-3);
            IEnumerable<BithInfo> notes = _birthRepository.GetAllAsync().Where(p=>p.Date.Day<today.Day).Where(p=>p.Date.Day>previous.Day).Where(p => p.Date.Month == previous.Month).ToList();
            var mapper = new MapperConfiguration(cfg => cfg.CreateMap<BithInfo, BirthDto>()).CreateMapper();
            IEnumerable<BirthDto> notess = mapper.Map<IEnumerable<BithInfo>, List<BirthDto>>(notes);
            return notess;

        }

        public IEnumerable<BirthDto> BirthSoon()
        {
            DateOnly today = DateOnly.FromDateTime(DateTime.Today);
            DateOnly previous = today.AddDays(+3);
            IEnumerable<BithInfo> notes = _birthRepository.GetAllAsync().Where(p => p.Date.Day > today.Day).Where(p => p.Date.Day < previous.Day).Where(p=>p.Date.Month==previous.Month).ToList();
            var mapper = new MapperConfiguration(cfg => cfg.CreateMap<BithInfo, BirthDto>()).CreateMapper();
            IEnumerable<BirthDto> notess = mapper.Map<IEnumerable<BithInfo>, List<BirthDto>>(notes);
            return notess;
        }

        public async Task<bool> CreateNewBirth(BirthDto entity)
        {
            if (entity == null)
            {
                return false;
            }
            else
            {
                BithInfo note = _mapper.Map<BithInfo>(entity);
                await _birthRepository.CreateNewBirth(note);
                await _birthRepository.SaveChangesAsync();
                return true;

            }
        }

        public async Task<bool> DeleteNote(int id)
        {
            await _birthRepository.DeleteAsync(id);
            return true;
        }

        public IEnumerable<BirthDto> GetAllBirth()
        {
            IEnumerable<BithInfo> notes = _birthRepository.GetAllAsync();
            var mapper = new MapperConfiguration(cfg => cfg.CreateMap<BithInfo, BirthDto>()).CreateMapper();
            IEnumerable<BirthDto> notess = mapper.Map<IEnumerable<BithInfo>, List<BirthDto>>(notes);
            return notess;
        }

        public IEnumerable<BirthDto> GetAllPicture()
        {
            throw new NotImplementedException();
        }

        public async Task<BirthDto> GetById(int id)
        {
            var note = await _birthRepository.GetById(id);
            BirthDto notes = _mapper.Map<BirthDto>(note);
            return notes;
        }
        
        public IEnumerable<BirthDto> TodayBirth()
        {
            DateOnly today = DateOnly.FromDateTime(DateTime.Today);
            IEnumerable<BithInfo> notes = _birthRepository.GetAllAsync().Where(p => p.Date.Day ==today.Day).Where(p => p.Date.Month == today.Month).ToList();
            var mapper = new MapperConfiguration(cfg => cfg.CreateMap<BithInfo, BirthDto>()).CreateMapper();
            IEnumerable<BirthDto> notess = mapper.Map<IEnumerable<BithInfo>, List<BirthDto>>(notes);
            return notess;

        }

        public async Task<bool> UpdateBirth(BirthDto entity)
        {
            BithInfo note = _mapper.Map<BithInfo>(entity);
            await _birthRepository.UpdateAsync(note);
            await _birthRepository.SaveChangesAsync();
            return true;

        }
    }
}
