﻿namespace PozdrApp.Models
{
    public class BirthView
    {
        public int Id { get; set; }
        public string Name { get; set; } 
        public string Surname { get; set; }  
        public DateOnly Date { get; set; }
        public byte[]? Picture { get; set; }
      //  public IFormFile? Avatar { get; set; }
    }
}
