﻿namespace PozdrApp.Models
{
    public class Picture
    {
       
        public IFormFile? Avatar { get; set; }
    }
}
