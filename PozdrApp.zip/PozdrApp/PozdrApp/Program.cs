using AutoMapper;
using DataLayer;
using DataLayer.IRepository;
using DataLayer.Model;
using PozdrApp.Mapper;
using ServiceLayer.Interfaces;
using ServiceLayer.ServiceLayer;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
var mapperConfiguration = new MapperConfiguration(config =>
{
    config.AddProfile(new MapProfile());
});
builder.Services.AddSingleton(mapperConfiguration.CreateMapper());
builder.Services.AddDbContext<BirthContext>();
builder.Services.AddTransient(typeof(IRepository<>), typeof(BaseRepository<>));
builder.Services.AddTransient<IBirthRepository, BirthRepository>();
builder.Services.AddTransient<IBirhtInfoService, BirthService>();



var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Birth}/{action=Get}/{id?}");

app.Run();
