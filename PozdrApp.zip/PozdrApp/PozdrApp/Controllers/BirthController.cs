﻿using AutoMapper;
using DataLayer.IRepository;
using DataLayer.Model;
using Microsoft.AspNetCore.Mvc;
using PozdrApp.Models;
using ServiceLayer.Interfaces;
using ServiceLayer.ModelDto;
using System.Runtime.CompilerServices;
using static Azure.Core.HttpHeader;

namespace PozdrApp.Controllers
{
    public class BirthController : Controller
    {
        private readonly IBirhtInfoService _birthInfoService;
        private readonly IMapper _mapper;

        public BirthController(IBirhtInfoService birhtInfoService, IMapper mapper)
        {
            _mapper = mapper;
            _birthInfoService = birhtInfoService;
        }
        public IActionResult Get()
        {
            List<BirthDto> k = _birthInfoService.GetAllBirth().ToList();

            var mapper = new MapperConfiguration(cfg => cfg.CreateMap<BirthDto, BirthView>()).CreateMapper();
            IEnumerable<BirthView> notess = mapper.Map<IEnumerable<BirthDto>, List<BirthView>>(k);
            ViewBag.Birth = notess;
            return View("index");
        }

        public IActionResult Create()
        {


            return View("Create");
        }
        [HttpPost]
        public async Task<ActionResult> Create(BirthView p, Picture t)
        {
            if (t.Avatar != null)
            {
                byte[] imageData = null;
                // считываем переданный файл в массив байтов
                using (var binaryReader = new BinaryReader(t.Avatar.OpenReadStream()))
                {
                    imageData = binaryReader.ReadBytes((int)t.Avatar.Length);
                }
                // установка массива байтов
                p.Picture = imageData;
            }
            BirthDto note = _mapper.Map<BirthDto>(p);
            await _birthInfoService.CreateNewBirth(note);


            return View();
        }

        public async Task<ActionResult> Delete(int id)
        {
            await _birthInfoService.DeleteNote(id);

            return RedirectToAction("Get");
        }

        public async Task<ActionResult> Update(int id)
        {
            BirthDto user = await _birthInfoService.GetById(id);

            BirthView note = _mapper.Map<BirthView>(user);
            return View("Update", note);

        }
        [HttpPost]
        public async Task<ActionResult> Update(BirthView p, Picture t)

        {
            if (t.Avatar != null)
            {
                byte[] imageData = null;
                // считываем переданный файл в массив байтов
                using (var binaryReader = new BinaryReader(t.Avatar.OpenReadStream()))
                {
                    imageData = binaryReader.ReadBytes((int)t.Avatar.Length);
                }
                // установка массива байтов
                p.Picture = imageData;
            }
            BirthDto note = _mapper.Map<BirthDto>(p);
            await _birthInfoService.UpdateBirth(note);

            return RedirectToAction("Get");

        }
        public IActionResult PastHolidays()
        {

            List<BirthDto> k = _birthInfoService.AlreadyPass().ToList();
            var mapper = new MapperConfiguration(cfg => cfg.CreateMap<BirthDto, BirthView>()).CreateMapper();
            IEnumerable<BirthView> notess = mapper.Map<IEnumerable<BirthDto>, List<BirthView>>(k);
            ViewBag.Birth = notess;

            return View("PastHolidays");

        }
        public IActionResult FutureHolidays()
        {

            List<BirthDto> k = _birthInfoService.BirthSoon().ToList();
            var mapper = new MapperConfiguration(cfg => cfg.CreateMap<BirthDto, BirthView>()).CreateMapper();
            IEnumerable<BirthView> notess = mapper.Map<IEnumerable<BirthDto>, List<BirthView>>(k);
            ViewBag.Birth = notess;

            return View("FutureHolidays");

        }
        public IActionResult TodayHolidays()
        {

            List<BirthDto> k = _birthInfoService.TodayBirth().ToList();
            var mapper = new MapperConfiguration(cfg => cfg.CreateMap<BirthDto, BirthView>()).CreateMapper();
            IEnumerable<BirthView> notess = mapper.Map<IEnumerable<BirthDto>, List<BirthView>>(k);
            ViewBag.Birth = notess;

            return View("TodayBirth");

        }
    }
}