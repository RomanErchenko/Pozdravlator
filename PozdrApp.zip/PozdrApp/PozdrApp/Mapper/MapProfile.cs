﻿using AutoMapper;
using DataLayer.Model;
using PozdrApp.Models;
using ServiceLayer.ModelDto;

namespace PozdrApp.Mapper
{
    public class MapProfile:Profile
    {
        public MapProfile()
        {

            CreateMap<BithInfo, BirthDto>().ReverseMap();

            CreateMap<BirthDto, BirthView>().ReverseMap();


        }
    }
}
