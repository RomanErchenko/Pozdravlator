﻿using DataLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.IRepository
{
    public interface IBirthRepository:IRepository<BithInfo>
    {
        Task<BithInfo> GetById(int id);
        Task<bool> CreateNewBirth (BithInfo entity);
        IEnumerable<BithInfo> GetAllBirth();
        Task<bool> UpdateBirth(BithInfo entity);
        Task<bool> DeleteNote(int id);
        new Task<bool> SaveChangesAsync();
    }
}
