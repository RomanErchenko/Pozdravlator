﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Model
{
    public class BirthContext : DbContext
    {

        public BirthContext(DbContextOptions<BirthContext> options)
       : base(options)
        {



        }

        public DbSet<BithInfo> BirthInfos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BithInfo>().HasData(
               new BithInfo { Id = 1, Name = "Dima", Surname = "Ivanov", Date = new DateOnly(2024, 07, 13) },
               new BithInfo { Id = 2, Name = "Pasha", Surname = "Petrov", Date = new DateOnly(2024, 07, 13) },
               new BithInfo { Id = 3, Name = "Kolya", Surname = "Nikolaev", Date = new DateOnly(2024, 07, 14) }
           );
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder
            .UseLazyLoadingProxies()
            .UseSqlServer(@"Data Source=DESKTOP-F8JLP97;Initial Catalog=PozdravlatoBase;Integrated Security = true;TrustServerCertificate=True");

        }
    }
}
