﻿using DataLayer.IRepository;
using DataLayer.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
     public class BirthRepository:BaseRepository<BithInfo>,IBirthRepository
    {
        private BirthContext Context;

        public BirthRepository(BirthContext context) : base(context)
        {
            Context = context;

        }

        public async Task<bool> DeleteNote(int id)
        {
            await Context.BirthInfos.Where(p => p.Id == id).ExecuteDeleteAsync();
            return true;
        }

        public IEnumerable<BithInfo> GetAllBirth()
        {
            return Context.BirthInfos.ToList();

        }

        


        public async Task<BithInfo> GetById(int id)
        {
            return await Context.BirthInfos.Where(p => p.Id == id).FirstAsync();
        }

        new public async Task<bool> SaveChangesAsync()
        {
            await Context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateBirth(BithInfo entity)
        {
            if (entity == null)
            {
                return false;
            }
            else
            {
                Context.Entry(entity).State = EntityState.Modified;
                await SaveChangesAsync();
                return true;
            }
        }

        public async Task<bool> CreateNewBirth(BithInfo entity)
        {
            if (entity == null)
            {
                return false;
            }
            else
            {

                await Context.BirthInfos.AddAsync(entity);
                await SaveChangesAsync();
                return true;
            }
        }

    }
}
